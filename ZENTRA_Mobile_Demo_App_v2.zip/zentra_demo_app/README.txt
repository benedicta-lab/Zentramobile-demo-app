ZENTRA MOBILE DEMO — QUICK START

Files:
- index.html: interactive mobile-first demo with Home, Bundles, Usage and Help
- manifest.json: app name, icon and standalone display settings
- icon-192.png and icon-512.png: icons made from your uploaded Z logo
- sw.js: basic caching after first successful visit
- zentra-original-logo.jpg: copy of your logo

IMPORTANT: This is a concept demo only. Sample prices, balances, usage and selections are illustrative. It does not connect to a telecom network, sell data, process payments, or send feedback.

TO ADD IT TO YOUR ANDROID HOME SCREEN:
1. Extract this ZIP.
2. Publish the contents of this folder to an HTTPS static hosting service. GitHub Pages is one free option for a public repository. Public pages are visible on the internet; do not upload private information.
3. Open the published HTTPS site in Chrome on Android.
4. Tap Chrome's three-dot menu and choose Install app or Add to Home screen (wording can vary).
5. Confirm ZENTRA Mobile. If installable, the app uses the included logo icons.

Opening index.html directly from Downloads is not enough for PWA installation; it needs HTTPS hosting. This ZIP is not an APK.
